const db = require('../config/dbConfig');

const getAllApoyos = (callback) => {
    db.query('SELECT * FROM apoyosEstudiantiles', callback);
};

const getApoyosByNivel = (nivelId, callback) => {
    const query = `
        SELECT apoyosEstudiantiles.id, apoyosEstudiantiles.porcentaje
        FROM apoyosEstudiantiles
        JOIN apoyos_nivel ON apoyosEstudiantiles.id = apoyos_nivel.apoyo_id
        WHERE apoyos_nivel.nivel_id = ?
    `;
    db.query(query, [nivelId], callback);
};

const getApoyoById = (id, callback) => {
    db.query('SELECT * FROM apoyosEstudiantiles WHERE id = ?', [id], callback);
};

const createApoyo = (apoyo, callback) => {
    const { porcentaje } = apoyo;
    db.query('INSERT INTO apoyosEstudiantiles (porcentaje) VALUES (?)', [porcentaje], callback);
};

const deleteApoyo = (id, callback) => {
    db.query('DELETE FROM apoyosEstudiantiles WHERE id = ?', [id], callback);
};

const updateApoyo = (id, updates, callback) => {
    const queryParts = [];
    const queryValues = [];

    for (const key in updates) {
        if (updates.hasOwnProperty(key)) {
            queryParts.push(`${key} = ?`);
            queryValues.push(updates[key]);
        }
    }

    queryValues.push(id);
    const query = `UPDATE apoyosEstudiantiles SET ${queryParts.join(', ')} WHERE id = ?`;

    db.query(query, queryValues, callback);
};

module.exports = {
    getAllApoyos,
    getApoyosByNivel,
    getApoyoById,
    createApoyo,
    deleteApoyo,
    updateApoyo
};
