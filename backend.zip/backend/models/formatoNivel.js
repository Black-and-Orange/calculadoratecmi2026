// models/formatoNivel.js
const db = require('../config/dbConfig');

const getAllFormatoNiveles = (callback) => {
    db.query('SELECT * FROM formato_nivel', callback);
};

const getFormatoNivelById = (id, callback) => {
    db.query('SELECT * FROM formato_nivel WHERE id = ?', [id], callback);
};

const createFormatoNivel = (formatoNivel, callback) => {
    const { id_formato, id_nivel } = formatoNivel;
    db.query('INSERT INTO formato_nivel (id_formato, id_nivel) VALUES (?, ?)', [id_formato, id_nivel], callback);
};

const deleteFormatoNivel = (id, callback) => {
    db.query('DELETE FROM formato_nivel WHERE id_formato = ?', [id], callback);
};

const updateFormatoNivel = (id, updates, callback) => {
    const queryParts = [];
    const queryValues = [];

    for (const key in updates) {
        if (updates.hasOwnProperty(key)) {
            queryParts.push(`${key} = ?`);
            queryValues.push(updates[key]);
        }
    }

    queryValues.push(id);
    const query = `UPDATE formato_nivel SET ${queryParts.join(', ')} WHERE id_formato = ?`;

    db.query(query, queryValues, callback);
};

module.exports = {
    getAllFormatoNiveles,
    getFormatoNivelById,
    createFormatoNivel,
    deleteFormatoNivel,
    updateFormatoNivel
};
