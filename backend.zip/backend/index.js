const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const becasFijasRoutes = require('./routes/becasFijasRoutes');
const becasVariablesRoutes = require('./routes/becasVariablesRoutes');
const beneficiosRoutes = require('./routes/beneficiosRoutes');
const apoyosRoutes = require('./routes/apoyosRoutes');
const campusRoutes = require('./routes/campusRoutes');
const costoMateriaRoutes = require('./routes/costoMateriaRoutes');
const formatoRoutes = require('./routes/formatoRoutes');
const materiasRoutes = require('./routes/materiasRoutes');
const nivelRoutes = require('./routes/nivelRoutes');
const periodicidadRoutes = require('./routes/periodicidadRoutes');
const periodoRoutes = require('./routes/periodoRoutes');
const planesRoutes = require('./routes/planesRoutes');
const segurosRoutes = require('./routes/segurosRoutes');

const app = express();
app.use(bodyParser.json());
app.use(cors());

app.use('/api/apoyos', apoyosRoutes);
app.use('/api/becasFijas', becasFijasRoutes);
app.use('/api/becasVariables', becasVariablesRoutes);
app.use('/api/beneficios', beneficiosRoutes);
app.use('/api/campus', campusRoutes);
app.use('/api/costos', costoMateriaRoutes);
app.use('/api/formato', formatoRoutes);
app.use('/api/materias', materiasRoutes);
app.use('/api/nivel', nivelRoutes);
app.use('/api/periodicidad', periodicidadRoutes);
app.use('/api/periodo', periodoRoutes);
app.use('/api/planes', planesRoutes);
app.use('/api/seguros', segurosRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
